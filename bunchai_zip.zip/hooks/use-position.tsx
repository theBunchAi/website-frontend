import { useContext } from "react";
import { ContextObj } from "../context/app-context";

export default function usePosition() {
  const position = useContext(ContextObj);
  return position.positionState;
}
