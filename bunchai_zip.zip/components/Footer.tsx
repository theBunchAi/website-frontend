import { useRef, useEffect, useCallback } from "react";
import Image from "next/image";
import Link from "next/link";
import { BsDiscord, BsFacebook, BsInstagram, BsTwitter } from "react-icons/bs";
import usePosition from "@/hooks/use-position";

export default function Footer() {
  const footerRef = useRef<HTMLDivElement | null>(null);
  const [_, setPosition] = usePosition();
  const observerOptions = useRef({
    root: null,
    rootMargin: "-20px",
    threshold: 0.25,
  });
  const observerCallback: IntersectionObserverCallback = useCallback(
    (entries) => {
      const intersecting = entries[0]?.isIntersecting;
      if (intersecting) {
        setPosition(true);
      } else {
        setPosition(false);
      }
    },
    []
  );
  useEffect(() => {
    const footerObserver = new IntersectionObserver(
      observerCallback,
      observerOptions.current
    );
    if (footerRef.current) {
      footerObserver.observe(footerRef.current);
      return () => {
        footerObserver.disconnect();
      };
    }
    return;
  }, []);
  return (
    <footer className="footer" ref={footerRef}>
      <div className="img-container footer-img-container">
        <Image
          src="/assets/images/bg.png"
          alt="3D Swirl"
          fill
          priority
          sizes="100%"
          className="footer-img"
        />
      </div>
      <span className="year-span">2023</span>
      <div className="footer-links">
        <Link href="/">
          <BsTwitter />
        </Link>
        <Link href="/">
          <BsInstagram />
        </Link>
        <Link href="/">
          <BsFacebook />
        </Link>
        <Link href="/">
          <BsDiscord />
        </Link>
      </div>
    </footer>
  );
}
