import usePosition from "@/hooks/use-position";
import Image from "next/image";
import Link from "next/link";
import { useEffect, useRef } from "react";

export default function Header() {
  const [position] = usePosition();
  const headerRef = useRef<HTMLDivElement | null>(null);

  if (headerRef.current?.classList[1] === "inactive") {
    console.log(headerRef.current.getBoundingClientRect());
  }
  return (
    <header
      className={`header ${position ? "active" : "inactive"}`}
      ref={headerRef}
    >
      <Link href="/" className="img-container logo-container">
        <Image
          src="/assets/images/logo.png"
          alt="Logo"
          fill
          priority
          sizes="100%"
          className="logo"
        />
      </Link>
      <nav className="nav">
        <Link href="/" className="nav-links">
          Home
        </Link>
        <Link href="/" className="nav-links">
          Events
        </Link>
        <Link href="/" className="nav-links">
          Join
        </Link>
      </nav>
    </header>
  );
}
