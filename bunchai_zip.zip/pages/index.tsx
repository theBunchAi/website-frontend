import HomeContainer from "@/modules/home/home-container";

export default function Home() {
  return (
    <section id="home" aria-label="home">
      <HomeContainer />
    </section>
  );
}
