# Next.js starter template

This is a starter template for [Next.js](https://nextjs.org/) projects.  
This template includes the following features:

  * [TypeScript](https://www.typescriptlang.org/)
  * [ESLint](https://eslint.org/) with plugins 
  * [Sass](https://sass-lang.com/)

FYI: I have git ignored all css files and any lock files. 