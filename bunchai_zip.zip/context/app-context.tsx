import {
  Dispatch,
  PropsWithChildren,
  SetStateAction,
  createContext,
  useState,
} from "react";

interface ContextType {
  positionState: [boolean, Dispatch<SetStateAction<boolean>>];
}

const contextInit: ContextType = {
  positionState: [false, () => void 0],
};

export const ContextObj = createContext<ContextType>(contextInit);

export default function AppContext({ children }: PropsWithChildren) {
  const positionState = useState<boolean>(false);
  const contextProvider: ContextType = {
    positionState,
  };
  return (
    <ContextObj.Provider value={contextProvider}>
      {children}
    </ContextObj.Provider>
  );
}
